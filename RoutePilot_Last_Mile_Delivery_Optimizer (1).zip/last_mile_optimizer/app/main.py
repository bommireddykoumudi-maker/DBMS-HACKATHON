from fastapi import FastAPI, HTTPException, Query
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field, field_validator
from typing import Optional
from pathlib import Path
from contextlib import contextmanager
import sqlite3, math, os, hashlib, hmac, base64, json, time

ROOT = Path(__file__).resolve().parent.parent
DB = Path(os.getenv('ROUTEPILOT_DB', ROOT / 'delivery.db'))
app = FastAPI(title='RoutePilot | Last-Mile Delivery Optimizer', version='2.0.0', description='Unified delivery operations platform: orders, locations, drivers, assignments, status, analytics and route optimization.')

@contextmanager
def db():
    con = sqlite3.connect(DB, timeout=20)
    con.row_factory = sqlite3.Row
    con.execute('PRAGMA foreign_keys=ON')
    con.execute('PRAGMA journal_mode=WAL')
    try:
        yield con
        con.commit()
    except Exception:
        con.rollback(); raise
    finally: con.close()

def init_db():
    with db() as c:
        c.executescript('''
        CREATE TABLE IF NOT EXISTS locations(id INTEGER PRIMARY KEY AUTOINCREMENT,label TEXT NOT NULL UNIQUE,address TEXT NOT NULL,latitude REAL NOT NULL,longitude REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS drivers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,initials TEXT NOT NULL,phone TEXT NOT NULL UNIQUE,vehicle TEXT NOT NULL,capacity_kg REAL NOT NULL CHECK(capacity_kg>0),current_load_kg REAL NOT NULL DEFAULT 0 CHECK(current_load_kg>=0),status TEXT NOT NULL DEFAULT 'Available' CHECK(status IN ('Available','On delivery','Offline')),home_location_id INTEGER REFERENCES locations(id),created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS orders(id INTEGER PRIMARY KEY AUTOINCREMENT,customer TEXT NOT NULL,phone TEXT NOT NULL,location_id INTEGER NOT NULL REFERENCES locations(id),item TEXT NOT NULL,weight_kg REAL NOT NULL CHECK(weight_kg>0),priority TEXT NOT NULL DEFAULT 'Standard' CHECK(priority IN ('Standard','Express','Urgent')),status TEXT NOT NULL DEFAULT 'Pending' CHECK(status IN ('Pending','Assigned','Picked up','In transit','Delivered','Delayed')),created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS assignments(id INTEGER PRIMARY KEY AUTOINCREMENT,order_id INTEGER NOT NULL UNIQUE REFERENCES orders(id),driver_id INTEGER NOT NULL REFERENCES drivers(id),assigned_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,distance_km REAL NOT NULL DEFAULT 0,estimated_minutes INTEGER NOT NULL DEFAULT 0);
        CREATE TABLE IF NOT EXISTS delivery_events(id INTEGER PRIMARY KEY AUTOINCREMENT,order_id INTEGER NOT NULL REFERENCES orders(id),status TEXT NOT NULL,note TEXT NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS service_events(id INTEGER PRIMARY KEY AUTOINCREMENT,service TEXT NOT NULL,event_type TEXT NOT NULL,payload TEXT NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
        CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status); CREATE INDEX IF NOT EXISTS idx_orders_location ON orders(location_id); CREATE INDEX IF NOT EXISTS idx_assignments_driver ON assignments(driver_id); CREATE INDEX IF NOT EXISTS idx_events_order ON delivery_events(order_id);
        ''')
        # Safe additive migration for databases created by the earlier RoutePilot build.
        driver_cols={r['name'] for r in c.execute('PRAGMA table_info(drivers)')}
        if 'home_location_id' not in driver_cols: c.execute('ALTER TABLE drivers ADD COLUMN home_location_id INTEGER REFERENCES locations(id)')
        if c.execute('SELECT COUNT(*) FROM locations').fetchone()[0] == 0:
            c.executemany('INSERT INTO locations(label,address,latitude,longitude) VALUES(?,?,?,?)',[
            ('Banjara Hills','Road No. 12, Banjara Hills, Hyderabad',17.4126,78.4482),('Jubilee Hills','Jubilee Hills Check Post, Hyderabad',17.4310,78.4070),('Madhapur','HITEC City, Madhapur, Hyderabad',17.4483,78.3915),('Gachibowli','DLF Cyber City, Gachibowli, Hyderabad',17.4401,78.3489),('Begumpet','Begumpet Main Road, Hyderabad',17.4435,78.4630),('Kondapur','Kondapur Main Road, Hyderabad',17.4615,78.3568),('Kukatpally','KPHB, Kukatpally, Hyderabad',17.4933,78.3996),('Secunderabad','Clock Tower, Secunderabad',17.4399,78.4983)])
            locs={r['label']:r['id'] for r in c.execute('SELECT id,label FROM locations')}
            drivers=[('Aarav Mehta','AM','+91 98765 43210','Bike · TS 09 AB 2145',35,4,'Available','Madhapur'),('Diya Reddy','DR','+91 98765 43211','Bike · TS 10 CD 8872',30,12,'On delivery','Jubilee Hills'),('Kabir Shah','KS','+91 98765 43212','Van · TS 08 EF 3310',120,18,'Available','Gachibowli'),('Ananya Rao','AR','+91 98765 43213','Bike · TS 09 GH 5621',25,2,'Available','Banjara Hills')]
            c.executemany('INSERT INTO drivers(name,initials,phone,vehicle,capacity_kg,current_load_kg,status,home_location_id) VALUES(?,?,?,?,?,?,?,?)',[(a,b,d,e,f,g,h,locs[i]) for a,b,d,e,f,g,h,i in drivers])
            orders=[('Ishita Sharma','+91 90000 10001','Banjara Hills','Electronics parcel',2.4,'Express','Pending'),('Rohan Varma','+91 90000 10002','Madhapur','Grocery essentials',7.2,'Standard','Pending'),('Meera Kapoor','+91 90000 10003','Jubilee Hills','Fashion package',1.8,'Urgent','Assigned'),('Arjun Nair','+91 90000 10004','Gachibowli','Home supplies',9.5,'Standard','In transit'),('Sana Khan','+91 90000 10005','Begumpet','Document envelope',0.4,'Express','Delivered'),('Neil Joseph','+91 90000 10006','Kondapur','Kitchen appliance',14.0,'Standard','Pending')]
            c.executemany('INSERT INTO orders(customer,phone,location_id,item,weight_kg,priority,status) VALUES(?,?,?,?,?,?,?)',[(a,b,locs[x],d,e,f,g) for a,b,x,d,e,f,g in orders])
            c.execute('INSERT INTO assignments(order_id,driver_id,distance_km,estimated_minutes) VALUES(3,2,4.8,18)');c.execute('INSERT INTO assignments(order_id,driver_id,distance_km,estimated_minutes) VALUES(4,3,7.2,25)')
            c.executemany('INSERT INTO delivery_events(order_id,status,note) VALUES(?,?,?)',[(1,'Pending','Order created'),(2,'Pending','Order created'),(3,'Assigned','Driver Diya accepted the delivery'),(4,'In transit','Package is on the way'),(5,'Delivered','Delivery completed'),(6,'Pending','Order created')])

class DriverIn(BaseModel):
    name:str=Field(min_length=2,max_length=80); phone:str=Field(min_length=8,max_length=20); vehicle:str=Field(min_length=2,max_length=80); capacity_kg:float=Field(gt=0,le=2000); home_location_id:Optional[int]=None
class DriverUpdate(BaseModel):
    status:str
class OrderIn(BaseModel):
    customer:str=Field(min_length=2,max_length=80);phone:str=Field(min_length=8,max_length=20);location_id:int;item:str=Field(min_length=2,max_length=100);weight_kg:float=Field(gt=0,le=500);priority:str='Standard'
    @field_validator('priority')
    @classmethod
    def valid_priority(cls,v):
        if v not in ('Standard','Express','Urgent'): raise ValueError('Priority must be Standard, Express or Urgent')
        return v
class StatusIn(BaseModel): status:str
class AssignIn(BaseModel): driver_id:int

def initials(name): return ''.join(p[0] for p in name.split()[:2]).upper()
def haversine(a,b):
    r=6371;p1,p2=math.radians(a['latitude']),math.radians(b['latitude']);dp=math.radians(b['latitude']-a['latitude']);dl=math.radians(b['longitude']-a['longitude']);x=math.sin(dp/2)**2+math.cos(p1)*math.cos(p2)*math.sin(dl/2)**2;return 2*r*math.asin(math.sqrt(x))
def log_service(c,service,event,payload): c.execute('INSERT INTO service_events(service,event_type,payload) VALUES(?,?,?)',(service,event,json.dumps(payload)))
def assign(c,order,driver):
    if driver['capacity_kg']-driver['current_load_kg']+1e-9 < order['weight_kg']: raise HTTPException(400,'Driver does not have enough remaining capacity')
    dest=c.execute('SELECT * FROM locations WHERE id=?',(order['location_id'],)).fetchone(); home=c.execute('SELECT * FROM locations WHERE id=?',(driver['home_location_id'],)).fetchone() if driver['home_location_id'] else None
    origin=home or {'latitude':17.425,'longitude':78.415};km=round(haversine(origin,dest)*1.25,1);mins=max(8,round(km/0.32))
    c.execute('INSERT INTO assignments(order_id,driver_id,distance_km,estimated_minutes) VALUES(?,?,?,?)',(order['id'],driver['id'],km,mins));c.execute("UPDATE orders SET status='Assigned' WHERE id=?",(order['id'],));newload=driver['current_load_kg']+order['weight_kg'];c.execute("UPDATE drivers SET current_load_kg=?,status='On delivery' WHERE id=?",(newload,driver['id']));c.execute("INSERT INTO delivery_events(order_id,status,note) VALUES(?,'Assigned',?)",(order['id'],f"Assigned to {driver['name']} · {km} km estimated"));log_service(c,'dispatch','order.assigned',{'order_id':order['id'],'driver_id':driver['id'],'distance_km':km,'eta_minutes':mins});return {'order_id':order['id'],'driver':driver['name'],'driver_id':driver['id'],'location':dest['label'],'distance_km':km,'eta_minutes':mins}

@app.on_event('startup')
def startup(): init_db()
@app.get('/api/health')
def health():
    with db() as c: c.execute('SELECT 1')
    return {'status':'ok','service':'RoutePilot unified backend','database':'connected'}
@app.get('/api/overview')
def overview():
    with db() as c:
        counts={r['status']:r['n'] for r in c.execute('SELECT status,COUNT(*) n FROM orders GROUP BY status')};total=sum(counts.values());drivers=c.execute("SELECT COUNT(*) FROM drivers WHERE status!='Offline'").fetchone()[0];assigned=c.execute('SELECT COUNT(*) FROM assignments').fetchone()[0];delivered=counts.get('Delivered',0)
        return {'total_orders':total,'pending':counts.get('Pending',0),'assigned':counts.get('Assigned',0),'in_transit':counts.get('In transit',0)+counts.get('Picked up',0),'delivered':delivered,'delayed':counts.get('Delayed',0),'active_drivers':drivers,'assigned_total':assigned,'success_rate':round(delivered/total*100) if total else 0,'status_breakdown':counts}
@app.get('/api/orders')
def list_orders(q:Optional[str]=None,status:Optional[str]=None):
    sql='''SELECT o.*,l.label location,l.address,l.latitude,l.longitude,a.driver_id,d.name driver,a.distance_km,a.estimated_minutes FROM orders o JOIN locations l ON l.id=o.location_id LEFT JOIN assignments a ON a.order_id=o.id LEFT JOIN drivers d ON d.id=a.driver_id WHERE 1=1''';args=[]
    if status and status!='All':sql+=' AND o.status=?';args.append(status)
    if q:sql+=' AND (CAST(o.id AS TEXT) LIKE ? OR o.customer LIKE ? OR o.item LIKE ? OR l.label LIKE ?)';args += [f'%{q}%']*4
    sql+=" ORDER BY CASE o.priority WHEN 'Urgent' THEN 0 WHEN 'Express' THEN 1 ELSE 2 END,o.id DESC"
    with db() as c:return [dict(r) for r in c.execute(sql,args)]
@app.post('/api/orders',status_code=201)
def create_order(data:OrderIn):
    with db() as c:
        if not c.execute('SELECT id FROM locations WHERE id=?',(data.location_id,)).fetchone():raise HTTPException(404,'Location not found')
        cur=c.execute('INSERT INTO orders(customer,phone,location_id,item,weight_kg,priority) VALUES(?,?,?,?,?,?)',(data.customer,data.phone,data.location_id,data.item,data.weight_kg,data.priority));oid=cur.lastrowid;c.execute("INSERT INTO delivery_events(order_id,status,note) VALUES(?,'Pending','Order created')",(oid,));log_service(c,'orders','order.created',{'order_id':oid});return {'id':oid,'message':'Order created successfully'}
@app.get('/api/drivers')
def list_drivers():
    with db() as c:return [dict(r) for r in c.execute('''SELECT d.*,l.label home_location,COUNT(CASE WHEN o.status NOT IN ('Delivered') THEN 1 END) active_orders FROM drivers d LEFT JOIN locations l ON l.id=d.home_location_id LEFT JOIN assignments a ON a.driver_id=d.id LEFT JOIN orders o ON o.id=a.order_id GROUP BY d.id ORDER BY d.id''')]
@app.post('/api/drivers',status_code=201)
def create_driver(data:DriverIn):
    with db() as c:
        if data.home_location_id and not c.execute('SELECT id FROM locations WHERE id=?',(data.home_location_id,)).fetchone():raise HTTPException(404,'Home location not found')
        try:
            cur=c.execute('INSERT INTO drivers(name,initials,phone,vehicle,capacity_kg,home_location_id) VALUES(?,?,?,?,?,?)',(data.name,initials(data.name),data.phone,data.vehicle,data.capacity_kg,data.home_location_id));did=cur.lastrowid;log_service(c,'fleet','driver.created',{'driver_id':did});return {'id':did,'message':'Driver added successfully'}
        except sqlite3.IntegrityError as e:raise HTTPException(409,'A driver with this phone number already exists') from e
@app.patch('/api/drivers/{driver_id}')
def update_driver(driver_id:int,data:DriverUpdate):
    if data.status not in ('Available','On delivery','Offline'):raise HTTPException(400,'Invalid driver status')
    with db() as c:
        if not c.execute('SELECT id FROM drivers WHERE id=?',(driver_id,)).fetchone():raise HTTPException(404,'Driver not found')
        active=c.execute("SELECT COUNT(*) FROM assignments a JOIN orders o ON o.id=a.order_id WHERE a.driver_id=? AND o.status NOT IN ('Delivered')",(driver_id,)).fetchone()[0]
        if data.status in ('Available','Offline') and active:raise HTTPException(409,'Driver has active deliveries. Complete them before changing to Available or Offline.')
        c.execute('UPDATE drivers SET status=? WHERE id=?',(data.status,driver_id));return {'message':'Driver updated','status':data.status}
@app.get('/api/locations')
def locations():
    with db() as c:return [dict(r) for r in c.execute('SELECT * FROM locations ORDER BY label')]
@app.post('/api/assignments/{order_id}')
def manual_assign(order_id:int,data:AssignIn):
    with db() as c:
        order=c.execute("SELECT * FROM orders WHERE id=?",(order_id,)).fetchone();driver=c.execute("SELECT * FROM drivers WHERE id=?",(data.driver_id,)).fetchone()
        if not order:raise HTTPException(404,'Order not found')
        if not driver:raise HTTPException(404,'Driver not found')
        if order['status']!='Pending':raise HTTPException(409,'Only pending orders can be assigned')
        if driver['status']=='Offline':raise HTTPException(409,'Driver is offline')
        if c.execute('SELECT id FROM assignments WHERE order_id=?',(order_id,)).fetchone():raise HTTPException(409,'Order already assigned')
        return assign(c,order,driver)
@app.post('/api/optimize')
def optimize():
    assigned=[];skipped=[]
    with db() as c:
        pending=c.execute("SELECT * FROM orders WHERE status='Pending' ORDER BY CASE priority WHEN 'Urgent' THEN 0 WHEN 'Express' THEN 1 ELSE 2 END,id").fetchall();drivers=[dict(x) for x in c.execute("SELECT * FROM drivers WHERE status IN ('Available','On delivery') ORDER BY id")]
        for order in pending:
            eligible=[d for d in drivers if d['capacity_kg']-d['current_load_kg']>=order['weight_kg']]
            if not eligible:skipped.append({'order_id':order['id'],'reason':'No available driver has sufficient remaining capacity'});continue
            dest=c.execute('SELECT * FROM locations WHERE id=?',(order['location_id'],)).fetchone()
            def score(d):
                home=c.execute('SELECT latitude,longitude FROM locations WHERE id=?',(d['home_location_id'],)).fetchone() if d['home_location_id'] else None
                origin=home or {'latitude':17.425,'longitude':78.415};return (haversine(origin,dest),d['current_load_kg']/d['capacity_kg'])
            chosen=min(eligible,key=score);result=assign(c,order,chosen);chosen['current_load_kg']+=order['weight_kg'];chosen['status']='On delivery';assigned.append(result)
        log_service(c,'dispatch','optimization.completed',{'assigned':len(assigned),'skipped':len(skipped)})
    return {'assigned':assigned,'skipped':skipped,'count':len(assigned)}
@app.patch('/api/orders/{order_id}/status')
def update_status(order_id:int,data:StatusIn):
    allowed=['Pending','Assigned','Picked up','In transit','Delivered','Delayed']
    if data.status not in allowed:raise HTTPException(400,'Invalid delivery status')
    with db() as c:
        row=c.execute('SELECT * FROM orders WHERE id=?',(order_id,)).fetchone()
        if not row:raise HTTPException(404,'Order not found')
        old=row['status'];a=c.execute('SELECT driver_id FROM assignments WHERE order_id=?',(order_id,)).fetchone()
        if data.status=='Pending' and a:raise HTTPException(409,'Unassign this delivery before returning it to pending')
        if data.status in ('Assigned','Picked up','In transit','Delivered') and not a:raise HTTPException(409,'Assign this order to a driver before moving it to this status')
        c.execute('UPDATE orders SET status=? WHERE id=?',(data.status,order_id));c.execute('INSERT INTO delivery_events(order_id,status,note) VALUES(?,?,?)',(order_id,data.status,f'Status changed from {old} to {data.status}'))
        if a and data.status=='Delivered' and old!='Delivered':
            d=c.execute('SELECT * FROM drivers WHERE id=?',(a['driver_id'],)).fetchone();load=max(0,d['current_load_kg']-row['weight_kg']);active=c.execute("SELECT COUNT(*) FROM assignments a JOIN orders o ON o.id=a.order_id WHERE a.driver_id=? AND o.status!='Delivered'",(a['driver_id'],)).fetchone()[0];c.execute('UPDATE drivers SET current_load_kg=?,status=? WHERE id=?',(load,'On delivery' if active else 'Available',a['driver_id']))
        log_service(c,'orders','order.status_changed',{'order_id':order_id,'from':old,'to':data.status});return {'message':'Status updated','order_id':order_id,'status':data.status}
@app.get('/api/orders/{order_id}/events')
def events(order_id:int):
    with db() as c:
        if not c.execute('SELECT id FROM orders WHERE id=?',(order_id,)).fetchone():raise HTTPException(404,'Order not found')
        return [dict(r) for r in c.execute('SELECT * FROM delivery_events WHERE order_id=? ORDER BY created_at DESC,id DESC',(order_id,))]
@app.get('/api/analytics')
def analytics():
    with db() as c:
        status=[dict(r) for r in c.execute('SELECT status,COUNT(*) value FROM orders GROUP BY status ORDER BY value DESC')]
        priorities=[dict(r) for r in c.execute('SELECT priority,COUNT(*) value FROM orders GROUP BY priority')]
        locations=[dict(r) for r in c.execute('SELECT l.label,COUNT(o.id) value FROM locations l LEFT JOIN orders o ON o.location_id=l.id GROUP BY l.id ORDER BY value DESC LIMIT 6')]
        drivers=[dict(r) for r in c.execute('SELECT d.name,COUNT(a.id) assignments FROM drivers d LEFT JOIN assignments a ON a.driver_id=d.id GROUP BY d.id ORDER BY assignments DESC LIMIT 5')]
        return {'status':status,'priorities':priorities,'locations':locations,'drivers':drivers}
@app.get('/api/assignments')
def assignments():
    with db() as c:return [dict(r) for r in c.execute('''SELECT a.*,o.customer,o.item,o.weight_kg,o.status order_status,l.label location,d.name driver,d.vehicle FROM assignments a JOIN orders o ON o.id=a.order_id JOIN locations l ON l.id=o.location_id JOIN drivers d ON d.id=a.driver_id ORDER BY a.id DESC''')]
@app.get('/api/database/summary')
def db_summary():
    with db() as c:
        tables=['locations','drivers','orders','assignments','delivery_events','service_events'];return {'engine':'SQLite relational database','tables':{t:c.execute(f'SELECT COUNT(*) FROM {t}').fetchone()[0] for t in tables},'foreign_keys':'enabled','indexes':['idx_orders_status','idx_orders_location','idx_assignments_driver','idx_events_order']}

app.mount('/static',StaticFiles(directory=ROOT/'static'),name='static')
@app.get('/')
def home():return FileResponse(ROOT/'static'/'index.html')
